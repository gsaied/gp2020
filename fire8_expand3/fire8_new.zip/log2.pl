#!/usr/bin/perl
use warnings ;
use Math::Complex; 
use POSIX ;
use strict ;
my $var= ceil(logn($ARGV[0],2));
print $var ; 
